install.packages(c("rmarkdown", "pagedown", "knitr", "tidyverse"))

# render the Rmd to HTML
rmarkdown::render("studentposter.Rmd")

# save the HTML as PDF using Chrome/Chromium
pagedown::chrome_print(
  input = "studentposter.html",
  output = "studentposter.pdf",
  options = list(
    printBackground = TRUE,
    preferCSSPageSize = TRUE
  )
)